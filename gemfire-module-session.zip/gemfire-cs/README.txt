VMware vFabric(TM) GemFire(R) HTTP Session Management Module 2.1.2 for vFabric tc Server (client/server template)

This module provides fast, scalable, and reliable HTTP session replication for tc Server.

Access all GemFire documentation at the vFabric GemFire Product Page at:
https://www.vmware.com/support/pubs/vfabric-gemfire.html

VMware Support Services can be accessed from the VMware Web site
or via the phone. Access varies by license type, support offering
(contract or per-incident) and product. For instructions on how to
file a Support Request, please see the VMware web page below on
"How to File a Support Request".

https://www.vmware.com/support/policies/howto.html
